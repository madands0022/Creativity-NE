# Hospital Management System
A simple Hospital Management System in .NET core and React with SQL Server
