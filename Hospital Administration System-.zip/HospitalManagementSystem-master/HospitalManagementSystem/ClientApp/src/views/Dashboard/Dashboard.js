import React, { Component } from 'react';

class Dashboard extends Component {
  render() {
    return (
      <div className="animated fadeIn">
      </div>
    );
  }
}

export default Dashboard;
